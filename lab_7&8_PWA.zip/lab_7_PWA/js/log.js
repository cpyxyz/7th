localStorage.setItem("username" , "rvce");
localStorage.setItem("password" , "rvce");

function verify(){
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    let un = localStorage.getItem("username");
    let pass = localStorage.getItem("password");

    let stun = un.localeCompare(username);
    let spass = pass.localeCompare(password);

    if(username==un && password==pass){
        alert("authentication success");
        window.open("../second.html")
    }else{
        alert("authentication failure");
    }

}